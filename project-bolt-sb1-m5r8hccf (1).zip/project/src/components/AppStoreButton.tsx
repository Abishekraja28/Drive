import React from 'react';

const AppStoreButton: React.FC = () => {
  return (
    <a 
      href="#download" 
      className="flex items-center bg-gray-800 hover:bg-gray-700 text-white rounded-xl pl-4 pr-6 py-3 transition-all duration-300 border border-gray-700 hover:border-gray-600 shadow-lg hover:shadow-purple-500/20"
      id="download"
    >
      <span className="mr-3">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M17.0301 12.978C16.9638 12.9551 14.2195 11.8446 14.2195 8.52753C14.2195 5.70948 16.3353 4.53527 16.4139 4.49069C15.1871 2.7395 13.2698 2.52753 12.5905 2.51174C10.9735 2.34607 9.40292 3.52028 8.58644 3.52028C7.75417 3.52028 6.46158 2.52753 5.09556 2.55911C3.33859 2.59069 1.71577 3.55911 0.824357 5.11174C-1.00856 8.26967 0.317511 12.978 2.0745 15.7119C2.94091 17.0493 3.9498 18.5493 5.28168 18.4967C6.58008 18.4441 7.07113 17.6434 8.6355 17.6434C10.1841 17.6434 10.6414 18.4967 12.0021 18.4651C13.4004 18.4493 14.2835 17.1119 15.1184 15.7592C16.1275 14.2119 16.5533 12.6908 16.5691 12.6224C16.5375 12.6066 17.1004 12.978 17.0301 12.978Z" fill="white"/>
          <path d="M13.8439 1.23529C14.5547 0.373529 15.026 -0.762941 14.9083 -1.91765C13.8991 -1.87059 12.6637 -1.2 11.9215 0.0423529C11.2582 0.794118 10.698 1.90588 10.8315 3.0282C11.9689 3.10588 13.1017 2.09412 13.8439 1.23529Z" fill="white"/>
        </svg>
      </span>
      <div className="flex flex-col">
        <span className="text-xs text-gray-300">Download on the</span>
        <span className="text-base font-semibold -mt-0.5">App Store</span>
      </div>
    </a>
  );
};

export default AppStoreButton;