import React from 'react';

const GooglePlayButton: React.FC = () => {
  return (
    <a 
      href="#download" 
      className="flex items-center bg-gray-800 hover:bg-gray-700 text-white rounded-xl pl-4 pr-6 py-3 transition-all duration-300 border border-gray-700 hover:border-gray-600 shadow-lg hover:shadow-cyan-500/20"
    >
      <span className="mr-3">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M1.73184 0.400291C1.73184 0.400291 1.50978 0.622346 1.50978 1.066C1.50978 1.50966 1.50978 21.9538 1.50978 21.9538C1.50978 21.9538 1.50978 22.6197 1.95389 22.8417L13.6667 12.0431L1.73184 0.400291Z" fill="#EA4335"/>
          <path d="M14.1107 12.2654L17.999 16.0427L22.7763 13.267C22.7763 13.267 23.8872 12.6011 22.9984 11.7123L17.999 8.93639L14.1107 12.2654Z" fill="#FBBC04"/>
          <path d="M13.8887 12.0431L1.95389 22.8417C1.95389 22.8417 2.39802 23.2859 2.84214 23.2859C3.28625 23.2859 13.6667 12.0431 13.6667 12.0431H13.8887Z" fill="#34A853"/>
          <path d="M1.73193 0.400299C1.73193 0.400299 1.28781 0.622353 1.28781 1.28826C1.28781 1.95416 1.73193 2.39828 1.73193 2.39828L13.8888 12.0432L17.999 8.04767L1.73193 0.400299Z" fill="#4285F4"/>
        </svg>
      </span>
      <div className="flex flex-col">
        <span className="text-xs text-gray-300">GET IT ON</span>
        <span className="text-base font-semibold -mt-0.5">Google Play</span>
      </div>
    </a>
  );
};

export default GooglePlayButton;